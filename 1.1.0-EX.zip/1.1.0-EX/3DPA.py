"""
    Name:    3DPA.py
    Author:  Brian van der Schaaf (MassGaming25)
    Desc:    3d model calculator.
    Version: 1.1.0-EX
    Notes:   code cleanup, mat. type selection.

    Contact:
        Website:  https://brianvdschaaf1.webnode.co.uk/
        LinkedIn: https://www.linkedin.com/in/brian-van-der-schaaf-963638230/
        Github:   https://github.com/MassGaming25/ 
"""
###############################
#   Imports                   #
###############################
from tkinter import *
from tkinter.ttk import *
import webbrowser

###############################
#   Window                    #
###############################
window = Tk()
window.iconbitmap(r'ENTER PATH HERE')

###############################
#   Window content            #
###############################
window.title("3D Print Assistant")
window.geometry('550x200')

lbl = Label(window, text= "3D model price generator", font=("Arial Bold", 15))
lbl.grid(column=0, row=0)

comboLbl = Label(window, text= "Select material: ")
comboLbl.grid(column=0, row=1)

typeLbl = Label(window, text="Select variety: ")
typeLbl.grid(column=0, row=2)

EntryLbl = Label(window, text= "Model weight: ")
EntryLbl.grid(column=0, row=3)

resLbl = Label(window, text= "Please enter the weight of the object and the material.")
resLbl.grid(column=1, row=5)

verLbl = Label(window, text= "Version: 1.0", font=("Arial Bold", 11))
verLbl.grid(column=0, row=6)

def link():
    webbrowser.open_new_tab(r"https://github.com/MassGaming25/3DPrintAssist")
abtBtn = Button(window, text="Github", command= link)
abtBtn.grid(column=0, row=4)

###############################
#   Material select           #
###############################
combo = Combobox(window)
combo['values'] = ("Select...", "PLA", "PETG", "ASA", "ABS", "PC", "TPU")
combo.current(0)
combo.grid(column=1, row=1)

###############################
#   Radio buttons             #
###############################
selected = IntVar()
rad1 = Radiobutton(window, text= "Basic", value= 1, variable= selected)
rad2 = Radiobutton(window, text= "Carbon Fibre", value= 2, variable= selected)
rad3 = Radiobutton(window, text= "Translucent", value= 3, variable= selected)
rad4 = Radiobutton(window, text= "Matte", value= 4, variable= selected)
rad5 = Radiobutton(window, text= "Basic Gradient", value= 5, variable= selected)
rad6 = Radiobutton(window, text= "Glow", value= 6, variable= selected)
rad7 = Radiobutton(window, text= "Silk", value= 7, variable= selected)
rad8 = Radiobutton(window, text= "Tough", value= 8, variable= selected)
rad9 = Radiobutton(window, text= "Marble", value= 9, variable= selected)
rad10 = Radiobutton(window, text= "Aero", value= 10, variable= selected)
rad11 = Radiobutton(window, text= "Sparkle", value= 11, variable= selected)
rad12 = Radiobutton(window, text= "Metal", value= 12, variable= selected)
rad13 = Radiobutton(window, text= "Silk Dual", value= 13, variable= selected)

###############################
#   Entry Box                 #
###############################
txt = Entry(window, width= 23)
txt.grid(column=1, row=3)

###############################
#   genBtn Logic              #
###############################
def OnSelectFilament():
    if(combo.get() == "PLA"):
        rad1.grid(column= 1, row=2)
        rad2.grid(column= 2, row=2)
        rad4.grid(column= 3, row=2)
        rad5.grid(column= 4, row=2)
        rad6.grid(column= 5, row=2)
        rad7.grid(column= 6, row=2)
        rad8.grid(column= 7, row=2)
        rad9.grid(column= 8, row=2)
        rad10.grid(column= 9, row=2)
        rad11.grid(column= 10, row=2)
        rad12.grid(column= 11, row=2)
        rad13.grid(column= 12, row=2)
    elif(combo.get() == "PETG"):
        rad1.grid(column=1, row=2)
        rad2.grid(column=2, row=2)
        rad3.grid(column=3, row=2)
    elif(combo.get() == "ASA"):
        rad1.grid(column=1, row=2)
    elif(combo.get() == "ABS"):
        rad1.grid(column=1, row=2)
    elif(combo.get() == "TPU"):
        rad1.grid(column=1, row=2)
    elif(combo.get() == "PC"):
        rad1.grid(column=1, row=2)

###############################
#   exitBtn logic             #
###############################
def OnExit():
    window.destroy()

###############################
#   Calculator                #
###############################
def OnClicked():
    if(combo.get() == "PLA"):
        if selected.get() == 1:
            Val = 30
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 2:
            Val = 39
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))   
        elif selected.get() == 4:
            Val = 30
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 5:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 6:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 7:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 8:
            Val = 31
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 9:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 10:
            Val = 48
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 11:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 12:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 13:
            Val = 33
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        # Run in case of no item selected.     
        else:
            resLbl.config(text="Error: invalid type")
    elif(combo.get() == "PETG"):
        if selected.get() == 1:
            Val = 30
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 2:
            Val = 39
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        elif selected.get() == 3:
            Val = 30
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
        else:
            resLbl.config(text= "Error: Invalid type")
    elif(combo.get() == "ASA"):
        if selected.get() == 1:
            Val = 32
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
    elif(combo.get() == "ABS"):
        if selected.get() == 1:
            Val = 30
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
    elif(combo.get() == "PC"):
        if selected.get() == 1:
            Val = 43
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
    elif(combo.get() == "TPU"):
        if selected.get() == 1:
            Val = 44
            result = Val /1000 * int(txt.get())
            resLbl.config(text= "Total value: €" + str(result))
    else:
        resLbl.config(text= "ERROR: Invalid value(s)")

###############################
#   Buttons                   #
###############################
btn = Button(window, text = "Calculate", command= OnClicked)
btn.grid(column=1, row=4)

genBtn = Button(window, text='Generate types', command=OnSelectFilament)
genBtn.grid(column=0, row=5)

exitBtn = Button(window, text= "Exit", command= OnExit)
exitBtn.grid(column= 1, row=6)

###############################
#   Keep window running       #
###############################
window.mainloop()